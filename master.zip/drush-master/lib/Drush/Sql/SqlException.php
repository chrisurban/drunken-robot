<?php

namespace Drush\Sql;

class SqlException extends \Exception {}
