<?php

namespace Drush\User;

class UserSingle8 extends UserSingleBase {

}
